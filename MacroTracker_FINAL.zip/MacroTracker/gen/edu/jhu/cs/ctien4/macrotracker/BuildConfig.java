/** Automatically generated file. DO NOT MODIFY */
package edu.jhu.cs.ctien4.macrotracker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}